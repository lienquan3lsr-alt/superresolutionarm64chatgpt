# Super Resolution Android ARM64 — Patch V13

**Format:** source overlay plus an apply helper. This is **not** an installable JAR and does not claim a successful Android build.

## What changed from V12.1

1. **Repository layout corrected.** The upstream `187J3X1-114514/superresolution` repository uses `common/`, `fabric/`, and `native/` at the repository root. V12/V12.1 hard-coded `modules/...`, so their submodule paths, Java source paths, CMake source path, and JAR search path did not match upstream. V13 stores the overlay in the upstream root layout and the workflow detects either the upstream root layout or a `modules/`-prefixed fork.
2. **Submodule paths corrected.** Uses the `.gitmodules` paths under `native/cpp/SRNativeMain/third_party/` for FreeType and glslang.
3. **CMake provider flags corrected.** The upstream top-level native CMake exposes `SR_FSR`, `SR_XESS`, and `SR_DLSS`. V13 turns all three off for the first JNI-core-only Android build. This avoids configuring DLSS/XeSS/FSR SDK projects before their Android provider builds have been brought up.
4. **NDK updated to the Android NDK r28 beta 1 revision documented by the native project** (`28.0.12433566`).
5. **Preflight expanded.** Checks the 1.21.11 Fabric config, source layout, JDK 21, CMake, NDK, Gradle wrapper version, submodules, and the Android-specific CMake branch before attempting the native build.
6. **JAR output is explicitly labelled a candidate.** A JAR containing the ARM64 `.so` is only a packaging milestone. It is not proof that Android loads the library or that Vulkan/OpenGL interop and FSR upscaling work.

## Apply

1. Extract this ZIP into the root of the source repository (not into `common/`, `native/`, or `modules/`).
2. Run `bash apply-v13-overlay.sh` from the extracted overlay directory. The helper copies `common/` and `native/` into the detected repository layout. The `.github/` workflow and `scripts/` remain at repository root.
3. Review `git diff` before committing. Do not blindly commit unrelated changes.
4. Push the branch and run **Build Super Resolution Android ARM64 JAR** from GitHub Actions.

## Build stages / success criteria

- Configure the Android `arm64-v8a` CMake project.
- Build `SR_MAIN_LIB` with NDK and no unresolved native symbols.
- Verify ELF64/AArch64 and the required JNI exports.
- Embed the exact native library in Fabric resources.
- Run `:fabric:remapJar` for Minecraft 1.21.11.
- Verify the remapped JAR contains a byte-for-byte identical `lib/libSuperResolution+android+release.so`.

These checks only establish build and packaging success. Runtime validation still needs to be performed in a separate Zalith profile on the target Android device.

## Known limitations / honesty notes

- No full source repository was attached to this ChatGPT workspace, and the current environment cannot resolve GitHub or Gradle distribution hosts. Consequently, this workspace cannot execute the complete NDK/Gradle build or push commits to the user's repository.
- The upstream README warns that Android runtime support is not officially supported and that Android OpenGL translation layers have feature gaps. A successfully packaged JAR can still fail to load or fail during rendering.
- The workflow is an experimental diagnostic path. It must not be described as working FSR until the game launches, the native library loads, Vulkan external-memory/semaphore import passes on the device, and actual upscaled frames are verified.
