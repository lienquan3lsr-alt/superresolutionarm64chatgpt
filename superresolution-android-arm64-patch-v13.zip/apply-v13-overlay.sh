#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ ! -f "$ROOT/.github/workflows/build_android_arm64_jar.yml" || ! -f "$ROOT/native/cpp/SRNativeMain/CMakeLists.txt" ]]; then
    echo 'ERROR: Extract the V13 ZIP directly into the source repository root.' >&2
    exit 1
fi

if [[ -d "$ROOT/modules/native/cpp" && -d "$ROOT/modules/common" && -d "$ROOT/modules/fabric" ]]; then
    TARGET="$ROOT/modules"
    for path in common native; do
        mkdir -p "$TARGET/$path"
        cp -a "$ROOT/$path/." "$TARGET/$path/"
    done
    # The root-level common/native folders came from the overlay; remove these
    # duplicate staging copies after transferring them into the modules layout.
    rm -rf "$ROOT/common" "$ROOT/native"
    LAYOUT='modules/'
elif [[ -d "$ROOT/native/cpp" && -d "$ROOT/common" && -d "$ROOT/fabric" ]]; then
    LAYOUT='repository root (already in place)'
else
    echo 'ERROR: Could not detect target repository layout.' >&2
    echo 'Expected common/fabric/native at repository root or under modules/.' >&2
    exit 1
fi

chmod +x "$ROOT/scripts/android-arm64-preflight.sh"
printf 'Applied Android ARM64 overlay to layout: %s\n' "$LAYOUT"
printf 'Workflow and scripts are at repository root.\n'
printf 'Next: review git diff, then commit/push and run the workflow manually.\n'
