#!/usr/bin/env bash
set -euo pipefail

OVERLAY_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_ROOT="$(cd "${1:-$OVERLAY_ROOT}" && pwd)"

fail() { printf 'APPLY ERROR: %s\n' "$*" >&2; exit 1; }

[[ -d "$TARGET_ROOT" ]] || fail "Target repository does not exist: $TARGET_ROOT"
[[ -f "$OVERLAY_ROOT/.github/workflows/build_android_arm64_jar.yml" ]] || fail 'Overlay workflow is missing.'
[[ -s "$OVERLAY_ROOT/configs/1.21.11.json" ]] || fail 'Overlay Minecraft 1.21.11 config is missing.'
[[ -s "$OVERLAY_ROOT/scripts/android-arm64-preflight.sh" ]] || fail 'Android preflight script is missing.'
[[ -d "$OVERLAY_ROOT/common" && -d "$OVERLAY_ROOT/native/cpp" ]] || fail 'Overlay common/ and native/ source trees are missing.'

if [[ -d "$TARGET_ROOT/modules/native/cpp" && -d "$TARGET_ROOT/modules/common" && -d "$TARGET_ROOT/modules/fabric" ]]; then
    PREFIX='modules/'
    TARGET_LAYOUT='modules/'
elif [[ -d "$TARGET_ROOT/native/cpp" && -d "$TARGET_ROOT/common" && -d "$TARGET_ROOT/fabric" ]]; then
    PREFIX=''
    TARGET_LAYOUT='repository root'
else
    fail 'Target is not a complete Super Resolution repository (expected common/fabric/native at root or modules/common, modules/fabric, modules/native).'
fi

# The full project and wrapper belong to the target repository; this patch is an overlay.
for required in gradlew gradle/wrapper/gradle-wrapper.jar gradle/wrapper/gradle-wrapper.properties settings.gradle.kts; do
    [[ -s "$TARGET_ROOT/$required" ]] || fail "The full source repository is missing required build file: $required"
done

# Copy only overlay content into the existing project; do not replace the rest of the source tree.
if [[ "$OVERLAY_ROOT" != "$TARGET_ROOT" ]]; then
    mkdir -p "$TARGET_ROOT/${PREFIX}common" "$TARGET_ROOT/${PREFIX}native" \
             "$TARGET_ROOT/configs" "$TARGET_ROOT/scripts" \
             "$TARGET_ROOT/.github/workflows"
    cp -a "$OVERLAY_ROOT/common/." "$TARGET_ROOT/${PREFIX}common/"
    cp -a "$OVERLAY_ROOT/native/." "$TARGET_ROOT/${PREFIX}native/"

    CONFIG_TARGET="$TARGET_ROOT/configs/1.21.11.json"
    if [[ -f "$CONFIG_TARGET" ]] && ! cmp -s "$CONFIG_TARGET" "$OVERLAY_ROOT/configs/1.21.11.json"; then
        [[ -e "$CONFIG_TARGET.pre-v15" ]] || cp -a "$CONFIG_TARGET" "$CONFIG_TARGET.pre-v15"
    fi
    cp -f "$OVERLAY_ROOT/configs/1.21.11.json" "$CONFIG_TARGET"
    cp -f "$OVERLAY_ROOT/scripts/android-arm64-preflight.sh" "$TARGET_ROOT/scripts/android-arm64-preflight.sh"
    cp -f "$OVERLAY_ROOT/.github/workflows/build_android_arm64_jar.yml" \
          "$TARGET_ROOT/.github/workflows/build_android_arm64_jar.yml"
    cp -f "$OVERLAY_ROOT/README_ANDROID_ARM64_V15.1.4.md" \
          "$TARGET_ROOT/README_ANDROID_ARM64_V15.1.4.md"
else
    # Extracted directly into the repo root. In the modules/ layout the root-level
    # common/ and native/ folders are staging copies and must be moved into modules/.
    if [[ "$PREFIX" == 'modules/' ]]; then
        cp -a "$OVERLAY_ROOT/common/." "$TARGET_ROOT/modules/common/"
        cp -a "$OVERLAY_ROOT/native/." "$TARGET_ROOT/modules/native/"
        rm -rf "$TARGET_ROOT/common" "$TARGET_ROOT/native"
    fi
fi

chmod +x "$TARGET_ROOT/gradlew" "$TARGET_ROOT/scripts/android-arm64-preflight.sh"
chmod +x "$TARGET_ROOT/.github/workflows/build_android_arm64_jar.yml" 2>/dev/null || true

python3 - "$TARGET_ROOT/configs/1.21.11.json" "$TARGET_ROOT/gradle/wrapper/gradle-wrapper.properties" <<'PY'
import json, re, sys
cfg_path, wrapper_path = sys.argv[1:]
with open(cfg_path, encoding='utf-8') as f:
    cfg = json.load(f)
common = cfg.get('common') or {}
fabric = cfg.get('fabric') or {}
sodium = next((x.get('version') for x in (fabric.get('dependencies') or {}).get('modrinth', []) if x.get('name') == 'sodium'), None)
checks = {
    'Minecraft': common.get('minecraft_version') == '1.21.11',
    'Java 25': common.get('java_version') == 25,
    'Fabric Loader 0.20.1': fabric.get('loader_version') == '0.20.1',
    'Sodium 0.8.15 beta': sodium == '0.8.15-beta+mc1.21.11',
}
for label, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'} config: {label}")
if not all(checks.values()):
    raise SystemExit('The installed 1.21.11 config does not match the requested build target.')
with open(wrapper_path, encoding='utf-8') as f:
    wrapper = f.read()
if not re.search(r'gradle-9\.7\.1-bin\.zip', wrapper):
    raise SystemExit('The repository Gradle wrapper does not point to Gradle 9.7.1.')
print('PASS Gradle wrapper configuration: Gradle 9.7.1')
PY

printf '\nAndroid ARM64 overlay V15.1.4 applied.\n'
printf '  Target: %s\n' "$TARGET_ROOT"
printf '  Layout: %s\n' "$TARGET_LAYOUT"
printf '  Build wrapper: existing repository wrapper preserved\n'
printf '  Next: commit/push the changes, then run Actions workflow "Build Super Resolution Android ARM64 JAR".\n'
